class Tasse:
    def __init__(self, data):
        self.importo_dovuto = data['importoDovuto']
        self.semaforo = data['semaforo']
